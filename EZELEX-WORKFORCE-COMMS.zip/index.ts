import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

async function twilioSms(to: string, body: string) {
  const sid = Deno.env.get("TWILIO_ACCOUNT_SID");
  const token = Deno.env.get("TWILIO_AUTH_TOKEN");
  const from = Deno.env.get("TWILIO_FROM") || "EZELEX";
  if (!sid || !token) throw new Error("SMS is not configured. Add TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN to Supabase secrets.");
  const form = new URLSearchParams({ To: to, From: from, Body: body });
  const auth = btoa(`${sid}:${token}`);
  const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: form,
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data.message || "SMS provider rejected the message.");
  return data.sid;
}

async function resendEmail(to: string, subject: string, message: string) {
  const key = Deno.env.get("RESEND_API_KEY");
  const from = Deno.env.get("RESEND_FROM") || "EZELEX <notifications@ezelex.com>";
  if (!key) throw new Error("Email is not configured. Add RESEND_API_KEY to Supabase secrets.");
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from, to: [to], subject, text: message }),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data.message || "Email provider rejected the message.");
  return data.id;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "Missing authorization." }, 401);

    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const userClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: "Not authenticated." }, 401);

    const adminClient = createClient(url, service);
    const { data: admin, error: adminError } = await adminClient.from("worker_profiles")
      .select("id,role,active,full_name").eq("id", user.id).maybeSingle();
    if (adminError || !admin || admin.role !== "admin" || !admin.active) return json({ error: "EZELEX admin access required." }, 403);

    const input = await req.json();
    const channel = input.channel;
    const subject = String(input.subject || "EZELEX Message").trim();
    const message = String(input.message || "").trim();
    const workerIds: string[] = Array.isArray(input.worker_ids) ? input.worker_ids : [];
    const notificationType = String(input.notification_type || "general");
    if (!['sms','email'].includes(channel)) return json({ error: "Channel must be sms or email." }, 400);
    if (!message) return json({ error: "Message is required." }, 400);
    if (!workerIds.length) return json({ error: "Select at least one worker." }, 400);

    const { data: workers, error: workerError } = await adminClient.from("worker_profiles")
      .select("id,full_name,email,phone,active").in("id", workerIds).eq("role", "worker").eq("active", true);
    if (workerError) throw workerError;

    const results = [];
    for (const worker of workers || []) {
      const destination = channel === "sms" ? worker.phone : worker.email;
      let status = "sent", providerId = null, errorMessage = null;
      if (!destination) {
        status = "failed"; errorMessage = channel === "sms" ? "Worker has no phone number." : "Worker has no email address.";
      } else {
        try {
          providerId = channel === "sms" ? await twilioSms(destination, `EZELEX: ${message}`) : await resendEmail(destination, subject.startsWith("EZELEX") ? subject : `EZELEX — ${subject}`, message);
        } catch (e) {
          status = "failed"; errorMessage = e instanceof Error ? e.message : String(e);
        }
      }
      await adminClient.from("communication_logs").insert({ worker_id: worker.id, channel, subject, message, status, provider_message_id: providerId, error_message: errorMessage, sent_by: user.id });
      await adminClient.from("worker_notifications").insert({ worker_id: worker.id, title: subject.startsWith("EZELEX") ? subject : `EZELEX — ${subject}`, message, notification_type: notificationType });
      results.push({ worker_id: worker.id, status, error: errorMessage });
    }
    return json({ ok: true, results });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
});
