-- EZELEX Workforce Communications
-- Run this in Supabase SQL Editor before using SMS/email messaging.

create table if not exists public.communication_logs (
  id uuid primary key default gen_random_uuid(),
  worker_id uuid null references public.worker_profiles(id) on delete set null,
  channel text not null check (channel in ('sms','email')),
  subject text,
  message text not null,
  status text not null default 'queued' check (status in ('queued','sent','failed')),
  provider_message_id text,
  error_message text,
  sent_by uuid null references public.worker_profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.worker_notifications (
  id uuid primary key default gen_random_uuid(),
  worker_id uuid not null references public.worker_profiles(id) on delete cascade,
  title text not null,
  message text not null,
  notification_type text not null default 'general',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists communication_logs_worker_idx on public.communication_logs(worker_id, created_at desc);
create index if not exists worker_notifications_worker_idx on public.worker_notifications(worker_id, created_at desc);

alter table public.communication_logs enable row level security;
alter table public.worker_notifications enable row level security;

-- Workers can only see their own in-app notifications.
drop policy if exists "workers read own notifications" on public.worker_notifications;
create policy "workers read own notifications"
on public.worker_notifications for select
to authenticated
using (worker_id = auth.uid());

-- Active EZELEX admins can read communication history.
drop policy if exists "admins read communication logs" on public.communication_logs;
create policy "admins read communication logs"
on public.communication_logs for select
to authenticated
using (exists (
  select 1 from public.worker_profiles p
  where p.id = auth.uid() and p.role = 'admin' and p.active = true
));

-- Active EZELEX admins can read all worker notifications when needed by the dashboard.
drop policy if exists "admins read worker notifications" on public.worker_notifications;
create policy "admins read worker notifications"
on public.worker_notifications for select
to authenticated
using (exists (
  select 1 from public.worker_profiles p
  where p.id = auth.uid() and p.role = 'admin' and p.active = true
));
