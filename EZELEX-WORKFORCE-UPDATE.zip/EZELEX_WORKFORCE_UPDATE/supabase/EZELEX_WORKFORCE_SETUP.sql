-- EZELEX Workforce Management setup
-- Run once in Supabase SQL Editor.

alter table public.worker_profiles add column if not exists email text;
alter table public.worker_profiles add column if not exists phone text;
alter table public.worker_profiles add column if not exists contract_end_date date;

alter table public.sales add column if not exists status text not null default 'approved';
alter table public.sales add column if not exists rejection_reason text;

-- New worker sales start as pending. Existing sales remain approved.

create or replace view public.admin_sales_view as
select
  s.*,
  wp.worker_id,
  wp.full_name as worker_name
from public.sales s
left join public.worker_profiles wp on wp.id = s.worker_id;

create or replace function public.admin_update_sale_status(
  p_sale_id text,
  p_status text,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.worker_profiles
    where id = auth.uid() and role = 'admin' and active = true
  ) then
    raise exception 'Not authorised';
  end if;

  if p_status not in ('approved','rejected','pending') then
    raise exception 'Invalid sale status';
  end if;

  update public.sales
  set status = p_status,
      rejection_reason = case when p_status = 'rejected' then p_reason else null end
  where id::text = p_sale_id;

  if not found then raise exception 'Sale not found'; end if;
end;
$$;

create or replace function public.admin_delete_sale(p_sale_id text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.worker_profiles
    where id = auth.uid() and role = 'admin' and active = true
  ) then
    raise exception 'Not authorised';
  end if;

  delete from public.sales where id::text = p_sale_id;
  if not found then raise exception 'Sale not found'; end if;
end;
$$;

revoke all on function public.admin_update_sale_status(text,text,text) from public;
grant execute on function public.admin_update_sale_status(text,text,text) to authenticated;
revoke all on function public.admin_delete_sale(text) from public;
grant execute on function public.admin_delete_sale(text) to authenticated;
