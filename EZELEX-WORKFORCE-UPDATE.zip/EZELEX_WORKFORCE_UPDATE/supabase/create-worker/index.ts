import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) throw new Error('Missing authorisation')

    const url = Deno.env.get('SUPABASE_URL')!
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const userClient = createClient(url, anonKey, { global: { headers: { Authorization: authHeader } } })
    const adminClient = createClient(url, serviceKey)

    const { data: { user }, error: userError } = await userClient.auth.getUser()
    if (userError || !user) throw new Error('Not signed in')

    const { data: adminProfile } = await adminClient
      .from('worker_profiles')
      .select('id,role,active')
      .eq('id', user.id)
      .maybeSingle()
    if (!adminProfile || adminProfile.role !== 'admin' || !adminProfile.active) throw new Error('Not authorised')

    const body = await req.json()
    const { full_name, email, phone, worker_id, password, contract_end_date } = body
    if (!full_name || !email || !password || password.length < 8) throw new Error('Name, email and an 8+ character password are required')

    const { data: created, error: createError } = await adminClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    })
    if (createError) throw createError
    if (!created.user) throw new Error('Worker account was not created')

    const { error: profileError } = await adminClient.from('worker_profiles').insert({
      id: created.user.id,
      worker_id: worker_id || null,
      full_name,
      email,
      phone: phone || null,
      role: 'worker',
      active: true,
      contract_end_date: contract_end_date || null,
    })

    if (profileError) {
      await adminClient.auth.admin.deleteUser(created.user.id)
      throw profileError
    }

    return new Response(JSON.stringify({ ok: true, user_id: created.user.id }), {
      headers: { ...cors, 'Content-Type': 'application/json' },
    })
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 400,
      headers: { ...cors, 'Content-Type': 'application/json' },
    })
  }
})
